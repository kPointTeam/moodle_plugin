<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$string['pluginname'] = 'kPoint';
$string['configplugin'] = 'kPoint Configuration';
$string['pluginadministration'] = 'Plugin Administration';
$string['clientid'] = 'Client ID';
$string['secret'] = 'Secret';
$string['domain'] = 'Domain';
$string['keyword'] = 'Search videos';
$string['email'] = 'Email';
$string['displayname'] = 'Display Name';
$string['test_credentials'] = 'Test';
$string['lbl_info_credentials'] = 'Please Test credentials before saving.';
$string['msg_notvalid'] = 'Client ID or Secret is incorrect.';
$string['searchfilter'] = 'Filter';
$string['allvideo'] = 'All Videos';
$string['myvideo'] = 'My Videos';
$string['lbl_info_domain'] = 'Add only kPoint domain name(without protocol "http://" or "https://")';
$string['auth_via_accountno'] = 'Enable account number';
$string['enable_analytics'] = 'Enable viewership tracking';
$string['enable_userid'] = 'Enable UserID';
$string['account_no'] = 'Account number';
$string['user_accno_field'] = 'User profile field mapping to Account number';
$string['lbl_accountno_required'] = 'Account number is a required field';
